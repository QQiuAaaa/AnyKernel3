#!/system/bin/sh

MODDIR=${0%/*}
LANGUAGE=$(getprop persist.sys.locale | cut -d'-' -f1)
#sleep 30


# 函数：检查文件大小并删除不匹配的文件
# 参数1: 文件路径
# 参数2: writeback变量值（单位GB）
check_and_delete_file() {
    local file_path="$1"
    local writeback="$2"

    # 检查文件是否存在
    if [ ! -f "$file_path" ]; then
        echo "错误: 文件 '$file_path' 不存在"
        return 1
    fi

    # 获取文件大小（字节）
    local file_size_bytes=$(stat -c%s $file_path)

    # 转换为GB（浮点数计算）
    local file_size_gb=$(echo "scale=2; $file_size_bytes / (1024*1024*1024)" | bc)

    # 比较文件大小和writeback值
    if [ "$(echo "$file_size_gb != $writeback" | bc)" -eq 1 ]; then
        echo "文件大小 ${file_size_gb}GB 不等于 ${writeback}GB，正在删除..."
        rm -f "$file_path"
        if [ $? -eq 0 ]; then
            echo "文件已删除"
        else
            echo "删除文件失败"
            return 1
        fi
    else
        echo "文件大小 ${file_size_gb}GB 等于 ${writeback}GB，保留文件"
    fi
}


# Read configuration from zram.conf
source $MODDIR/zram.conf

su -c swapoff /dev/block/zram0
sleep 2
echo '1' > /sys/block/zram0/reset
echo '0' > /sys/block/zram0/disksize

# Attempt to set the compression algorithm and verify
echo "$algorithm" > /sys/block/zram0/comp_algorithm
# Read back the current algorithm to verify
current_algorithm=$(cat /sys/block/zram0/comp_algorithm | grep -o '\[.*\]' | tr -d '[]')

if [ "$current_algorithm" != "$algorithm" ]; then
    # Algorithm write failed, check zram_algorithms.txt
    if [ -f "$MODDIR/zram_algorithms.txt" ]; then
        if grep -q "^$algorithm false$" "$MODDIR/zram_algorithms.txt"; then
            # Algorithm marked as failed, skip it
            echo "Algorithm $algorithm marked as failed in zram_algorithms.txt, skipping."
        else
            # Algorithm not marked as failed.
            echo "$algorithm false" >>"$MODDIR/zram_algorithms.txt"
            sed -i 's/'"$algorithm"'/lz4/g' zram.conf
            echo "lz4" > /sys/block/zram0/comp_algorithm
        fi
    fi
    if [ "$LANGUAGE" = "zh" ]; then
        # 中文通知
        su -lp 2000 -c "cmd notification post -S bigtext -t 'ZRAM' 'Tag' '您选择的算法 "$algorithm" 暂不支持，请返回WebUI界面切换其他可用算法。'"
    else
        # English notification information
        su -lp 2000 -c "cmd notification post -S bigtext -t 'ZRAM' 'Tag' 'The algorithm "$algorithm" you selected is not supported. Please return to the WebUI interface and switch to another available algorithm.'"
    fi
fi

FILE="/data/writeback"

check_and_delete_file $FILE $writeback_block_size

# 判断 writeback 是否为 0
if [ "$writeback_block_size" -ne 0 ]; then
    # 检查文件是否存在，不存在则用 dd 创建
    if [ ! -f "$FILE" ]; then
        su -c dd if=/dev/zero of=${FILE} bs=1G count=${writeback_block_size}
    fi
    # 自动绑定到空闲设备
    LOOP_DEVICE=$(su -c losetup --show -f ${FILE})
    echo $LOOP_DEVICE > /sys/block/zram0/backing_dev
else
    echo "writeback is 0: Skipping file creation and loop setup."
fi

#echo '/dev/block/mapper/hybridswap_crypto' > /sys/block/zram0/hybridswap_loop_device
#echo '/dev/block/mapper/hybridswap_crypto' > /sys/block/zram0/backing_dev
echo "$size" > /sys/block/zram0/disksize
su -c mkswap /dev/block/zram0
su -c swapon -p32767 /dev/block/zram0